
# Build Instructions (Step-by-step)

## Option A - Build on a PC (recommended)
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Install Android SDK and set up Android Studio or command line tools.
3. In the project directory:
   - `flutter pub get`
   - `flutter build apk --release`
4. The release APK will be at:
   `build/app/outputs/flutter-apk/app-release.apk`
5. To install on mobile, transfer APK to phone and install (enable Unknown sources).

## Option B - Use an online CI builder (no PC)
You can use Codemagic or GitHub Actions to build the APK from source:
1. Create a GitHub repository and push this project.
2. Sign up to Codemagic (or configure GitHub Actions) to build Flutter Android APK.
3. Configure Android signing (upload keystore) or build unsigned debug APK.
4. Trigger a build and download the produced APK.

Need help with setting up Codemagic or GitHub Actions? Tell me and I will provide the exact config file and steps.

## Note about Firebase
The project references Firebase packages. To enable online sync:
1. Create a Firebase project.
2. Add Android app to Firebase and place `google-services.json` in `android/app/`.
3. Initialize Firebase in `main.dart` (there's a placeholder in the code).

If you don't want Firebase now, the app will still run offline with Hive storage.
