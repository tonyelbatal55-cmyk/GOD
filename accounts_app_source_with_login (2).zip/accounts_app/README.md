
# Accounts App - Prototype (Source)

This is a Flutter project skeleton for a simple Accounts App that works offline and syncs when online.
It is intended as an internal app for you and your sales rep.

**Important:** This environment cannot build APKs. Download this source and build the APK locally on a PC
with Flutter installed, or use an online build service (Codemagic, GitHub Actions) to produce the APK.

## What is included
- `lib/main.dart` : Prototype app (Hive local storage, connectivity check, simple UI)
- `pubspec.yaml` : Dependencies list
- `README_BUILD.md` : Step-by-step build & distribution instructions

## Next steps
1. Download the zip and extract.
2. Open project in your PC with Flutter & Android SDK.
3. Run `flutter pub get`.
4. For debug: `flutter run` or `flutter build apk --debug`.
5. For release: `flutter build apk --release` (follow Android signing steps in README_BUILD.md).

If you want, I can prepare GitHub Actions / Codemagic config instructions so you can build APK using your mobile (via these services).


## CI & Build
Added GitHub Actions workflow and codemagic.yaml for building APK automatically. See `.github/workflows/flutter_build.yml` and `codemagic.yaml`.

Follow SIGNING_INSTRUCTIONS.txt to sign the release APK.
