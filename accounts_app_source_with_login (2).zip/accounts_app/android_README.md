
# Android notes

If you plan to enable Firebase, add google-services.json to android/app/.
Also configure AndroidManifest and Gradle plugin as per Firebase setup docs.
