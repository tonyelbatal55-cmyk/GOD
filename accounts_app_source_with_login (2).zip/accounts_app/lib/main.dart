// lib/main.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('products');
  await Hive.openBox('invoices');
  await Hive.openBox('customers');
  await Hive.openBox('users');

  // Seed predefined users if not exist (option 1: predefined users only)
  var usersBox = Hive.box('users');
  if (!usersBox.containsKey('owner')) {
    usersBox.put('owner', {
      'username': 'owner',
      'password': '1234',
      'role': 'admin',
      'name': 'مالك المتجر'
    });
  }
  if (!usersBox.containsKey('rep')) {
    usersBox.put('rep', {
      'username': 'rep',
      'password': '1234',
      'role': 'sales',
      'name': 'مندوب المبيعات'
    });
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Accounts App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
      ),
      home: LoginPage(),
    );
  }
}

// ------------------ Login Page ------------------

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  String _error = '';

  void _login() {
    var usersBox = Hive.box('users');
    String username = _userController.text.trim();
    String password = _passController.text;
    bool found = false;
    usersBox.keys.forEach((k) {
      var u = usersBox.get(k);
      if (u['username'] == username && u['password'] == password) {
        found = true;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainAppScreen(user: u)));
      }
    });
    if (!found) {
      setState(() {
        _error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Using a simple color scheme similar to many billing apps (blue + white)
    return Scaffold(
      backgroundColor: Color(0xFF0D47A1),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 36),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    Icon(Icons.receipt_long, size: 80, color: Colors.white),
                    SizedBox(height: 12),
                    Text('برنامج الحسابات', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text('نسخة داخلية', style: TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              SizedBox(height: 40),
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _userController,
                        decoration: InputDecoration(labelText: 'اسم المستخدم'),
                      ),
                      SizedBox(height: 12),
                      TextField(
                        controller: _passController,
                        decoration: InputDecoration(labelText: 'كلمة المرور'),
                        obscureText: true,
                      ),
                      SizedBox(height: 12),
                      if (_error.isNotEmpty) Text(_error, style: TextStyle(color: Colors.red)),
                      SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: _login,
                        child: Padding(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                          child: Text('دخول'),
                        ),
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size.fromHeight(40),
                          backgroundColor: Color(0xFF0D47A1),
                        ),
                      ),
                      SizedBox(height: 6),
                      Text('المستخدمون المسبقون: owner / rep   كلمة المرور: 1234', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ),
              ),
              Spacer(),
              Center(child: Text('تطبيق حسابات - يعمل أوفلاين ويزامن عند الاتصال', style: TextStyle(color: Colors.white70))),
            ],
          ),
        ),
      ),
    );
  }
}

// ------------------ Main App with Bottom Navigation ------------------

class MainAppScreen extends StatefulWidget {
  final Map user;
  MainAppScreen({required this.user});
  @override
  _MainAppScreenState createState() => _MainAppScreenState();
}

class _MainAppScreenState extends State<MainAppScreen> {
  int _selectedIndex = 0;
  late StreamSubscription? connectivitySub;
  ConnectivityResult _connectivity = ConnectivityResult.none;

  final List<Widget> _pages = [];

  @override
  void initState() {
    super.initState();
    connectivitySub = Connectivity().onConnectivityChanged.listen((res) {
      setState(() => _connectivity = res);
      if (res != ConnectivityResult.none) {
        // TODO: trigger sync service
        print('Online - would sync now');
      }
    });
  }

  @override
  void dispose() {
    connectivitySub?.cancel();
    super.dispose();
  }

  void _logout() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage()));
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Widget _buildAppBarTitle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('مرحبا، ${widget.user['name'] ?? widget.user['username']}', style: TextStyle(fontSize: 16)),
        Text(_connectivity == ConnectivityResult.none ? 'أوفلاين' : 'أونلاين', style: TextStyle(fontSize: 12, color: Colors.white70)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // prepare pages here to include required ones
    final pages = [
      DashboardPage(user: widget.user),
      InvoicesPage(),
      ProductsPage(),
      CustomersPage(),
      ReportsPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: _buildAppBarTitle(),
        actions: [
          IconButton(icon: Icon(Icons.logout), onPressed: _logout),
        ],
        backgroundColor: Color(0xFF0D47A1),
      ),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFF0D47A1),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long), label: 'الفواتير'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory_2), label: 'المنتجات'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'العملاء'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'التقارير'),
        ],
      ),
    );
  }
}

// ------------------ Pages ------------------

class DashboardPage extends StatelessWidget {
  final Map user;
  DashboardPage({required this.user});

  @override
  Widget build(BuildContext context) {
    var invoicesBox = Hive.box('invoices');
    double total = 0;
    invoicesBox.values.forEach((inv) {
      try {
        total += (inv['total'] as num).toDouble();
      } catch (e) {}
    });

    return SingleChildScrollView(
      padding: EdgeInsets.all(12),
      child: Column(
        children: [
          Card(
            color: Color(0xFF0D47A1),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('اجمالي المبيعات', style: TextStyle(color: Colors.white70)),
                      SizedBox(height: 8),
                      Text(total.toStringAsFixed(2)+ ' ج', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                    ],
                  )),
                  Icon(Icons.thumb_up, color: Colors.white70, size: 36),
                ],
              ),
            ),
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _smallStatCard('الطلبات', Hive.box('invoices').length.toString())),
              SizedBox(width: 8),
              Expanded(child: _smallStatCard('المنتجات', Hive.box('products').length.toString())),
            ],
          ),
          SizedBox(height: 12),
          Card(
            child: ListTile(
              title: Text('أحدث 5 فواتير'),
              subtitle: Text('تستطيع الضغط لرؤية التفاصيل'),
              trailing: Icon(Icons.arrow_forward_ios),
            ),
          )
        ],
      ),
    );
  }

  Widget _smallStatCard(String title, String value) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(children: [
          Text(title),
          SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))
        ]),
      ),
    );
  }
}

class InvoicesPage extends StatefulWidget {
  @override
  _InvoicesPageState createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  Box invoicesBox = Hive.box('invoices');

  void _createInvoice() {
    var id = Uuid().v4();
    invoicesBox.put(id, {
      'id': id,
      'number': 'INV-' + DateTime.now().millisecondsSinceEpoch.toString(),
      'items': [],
      'total': 0.0,
      'paid': 0.0,
      'createdAt': DateTime.now().toIso8601String(),
      'createdBy': 'owner',
      'synced': false,
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ValueListenableBuilder(
        valueListenable: invoicesBox.listenable(),
        builder: (context, box, _) {
          var keys = box.keys.toList().reversed.toList();
          return ListView.builder(
            itemCount: keys.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) {
                return Padding(
                  padding: EdgeInsets.all(12),
                  child: ElevatedButton(onPressed: _createInvoice, child: Text('إنشاء فاتورة جديدة')),
                );
              }
              var k = keys[index-1];
              var inv = box.get(k);
              return ListTile(
                title: Text(inv['number'] ?? '-'),
                subtitle: Text('اجمالي: ' + (inv['total']?.toString() ?? '0')),
                trailing: inv['synced'] ? Icon(Icons.cloud_done) : Icon(Icons.cloud_off),
              );
            },
          );
        },
      ),
    );
  }
}

class ProductsPage extends StatefulWidget {
  @override
  _ProductsPageState createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  Box productsBox = Hive.box('products');

  void _addProductDialog() {
    final nameC = TextEditingController();
    final priceC = TextEditingController();
    final stockC = TextEditingController();
    showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text('إضافة منتج'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameC, decoration: InputDecoration(labelText: 'اسم المنتج')),
          TextField(controller: priceC, decoration: InputDecoration(labelText: 'السعر'), keyboardType: TextInputType.number),
          TextField(controller: stockC, decoration: InputDecoration(labelText: 'المخزون'), keyboardType: TextInputType.number),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('إلغاء')),
          ElevatedButton(onPressed: () {
            var id = Uuid().v4();
            productsBox.put(id, {
              'id': id,
              'name': nameC.text.trim(),
              'price': double.tryParse(priceC.text) ?? 0.0,
              'cost': 0.0,
              'stock': int.tryParse(stockC.text) ?? 0,
              'updatedAt': DateTime.now().toIso8601String(),
              'synced': false,
            });
            Navigator.pop(context);
            setState(() {});
          }, child: Text('حفظ')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ValueListenableBuilder(
        valueListenable: productsBox.listenable(),
        builder: (context, box, _) {
          var keys = box.keys.toList().reversed.toList();
          return Column(
            children: [
              Padding(
                padding: EdgeInsets.all(12),
                child: ElevatedButton(onPressed: _addProductDialog, child: Text('إضافة منتج جديد')),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: keys.length,
                  itemBuilder: (context, index) {
                    var k = keys[index];
                    var p = box.get(k);
                    return ListTile(
                      title: Text(p['name'] ?? '-'),
                      subtitle: Text('السعر: ' + (p['price']?.toString() ?? '0')),
                      trailing: Text('مخزن: ' + (p['stock']?.toString() ?? '0')),
                    );
                  },
                ),
              )
            ],
          );
        },
      ),
    );
  }
}

class CustomersPage extends StatefulWidget {
  @override
  _CustomersPageState createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  Box customersBox = Hive.box('customers');

  void _addCustomerDialog() {
    final nameC = TextEditingController();
    final phoneC = TextEditingController();
    showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: Text('إضافة عميل'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameC, decoration: InputDecoration(labelText: 'اسم العميل')),
          TextField(controller: phoneC, decoration: InputDecoration(labelText: 'الهاتف'), keyboardType: TextInputType.phone),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('إلغاء')),
          ElevatedButton(onPressed: () {
            var id = Uuid().v4();
            customersBox.put(id, {
              'id': id,
              'name': nameC.text.trim(),
              'phone': phoneC.text.trim(),
              'address': '',
              'balance': 0.0,
            });
            Navigator.pop(context);
            setState(() {});
          }, child: Text('حفظ')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ValueListenableBuilder(
        valueListenable: customersBox.listenable(),
        builder: (context, box, _) {
          var keys = box.keys.toList().reversed.toList();
          return Column(
            children: [
              Padding(
                padding: EdgeInsets.all(12),
                child: ElevatedButton(onPressed: _addCustomerDialog, child: Text('إضافة عميل جديد')),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: keys.length,
                  itemBuilder: (context, index) {
                    var k = keys[index];
                    var c = box.get(k);
                    return ListTile(
                      title: Text(c['name'] ?? '-'),
                      subtitle: Text('هاتف: ' + (c['phone'] ?? '-')),
                    );
                  },
                ),
              )
            ],
          );
        },
      ),
    );
  }
}

class ReportsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Simple report placeholders
    return Padding(
      padding: EdgeInsets.all(12),
      child: Column(
        children: [
          Card(child: ListTile(title: Text('تقرير مبيعات يومي'))),
          Card(child: ListTile(title: Text('تقرير أرباح'))),
          Card(child: ListTile(title: Text('تقرير مخزون'))),
        ],
      ),
    );
  }
}